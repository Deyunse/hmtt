<template>
  <van-cell-group>
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
    <van-cell title="单元格" value="内容" label="描述信息" />
  </van-cell-group>
</template>

<script>
export default {
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
.van-cell-group {
  margin-top: 174px;
}
</style>
