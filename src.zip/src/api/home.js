import request from '@/utils/requst'
/**
 * 我频道
 * @returns
 */
export const getMyChannels = () => {
  return request({
    url: 'user/channels'
  })
}
